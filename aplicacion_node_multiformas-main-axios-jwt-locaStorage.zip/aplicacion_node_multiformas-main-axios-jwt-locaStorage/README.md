# aplicacion_node_multiformas
Aplicación de node, explicando varios conceptos fundamentales
